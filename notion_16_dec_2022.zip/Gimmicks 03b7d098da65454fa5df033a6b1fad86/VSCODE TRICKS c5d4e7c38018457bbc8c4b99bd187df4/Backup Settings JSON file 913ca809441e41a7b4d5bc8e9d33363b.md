# Backup Settings.JSON file

```jsx
{
    //"git.ignoreMissingGitWarning": true,
    //"terminal.integrated.shell.windows": "C:\\Program Files\\Git\\bin\\bash.exe",
    "window.zoomLevel": 0,
    "editor.renderControlCharacters": false,
    "editor.formatOnSave": true,
    "database-client.showUser": true,
    "database-client.showTrigger": true,
    "database-client.showDiagram": true,
    "database-client.showQuery": true,
    "vim.easymotion": true,
    "vim.surround": true,
    "vim.incsearch": true,
    "vim.useSystemClipboard": true,
    "vim.useCtrlKeys": true,
    "vim.hlsearch": true,
    "vim.insertModeKeyBindings": [
        {
        "before": ["k", "j"],
        "after": ["<Esc>"]
        }
    ],
    "vim.normalModeKeyBindingsNonRecursive": [
        // {
        //     "before": [
        //         "<leader>",
        //         "d"
        //     ],
        //     "after": [
        //         "d",
        //         "d"
        //     ]
        // },
        {
            "before": [
                "<leader>",
                "d"
            ],
            "after": [
                "\"",
                "_",
                "d",
            ]
        }, 
        {
            "before": ["<leader>", "p"],
            "commands": [
                "workbench.action.showCommands",
            ]
        },
        {
            "before": ["<leader>", "f"],
            "commands": [
                "workbench.action.quickOpen",
            ],
        },
        {
            "before": ["<leader>", "o"],
            "commands": [
                "workbench.action.gotoSymbol",
            ]
        },
        {
            "before": ["<leader>", "t"],
            "commands": [
                "vim.showQuickpickCmdLine"
            ]
        },
        {
            "before": ["<leader>", "b"],
            "commands": [
            "open-buffers.openBuffer"
            ]
        },
        {
            "before": ["t", "t"],
            "after": [":"]
        },
        // {
        //     "before": ["t", "t", "w", "<Enter>"],
        //     "after": ["g","g","=","G","<C-o>"]
        // },
        {
            "before": ["<leader>", "c", "f"],
            "after": ["V","j","%","y"]
        },
        // {
        // "before": ["<C-n>"],
        // "commands": [":nohl"]
        // }
    ],
    "vim.visualModeKeyBindings": [
        {
            "before": [
                "y"
            ],
            "after":["y","g","v","<Esc>"]
        }
    ],
		"vim.visualModeKeyBindingsNonRecursive": [
        {
            "before": [
                "p",
            ],
            "after": [
                "p",
                "g",
                "v",
                "y"
            ]
        }
    ],
    "vim.leader": "<space>",
    "vim.smartcase": false,
		"vim.foldfix": true,
    "vim.handleKeys": {
        "<C-a>": false,
        "<C-f>": false,
        "<C-c>": false,
        "<C-v>": false,
        "<C-x>": false,
        "<C-w>": true,
        "<C-h>": false
    },
    "editor.lineNumbers": "relative",
    "workbench.editorAssociations": {
        "*.ipynb": "jupyter.notebook.ipynb"
    },
    "editor.minimap.enabled": false,
    // Mainly for static files
    "liveServer.settings.useWebExt": true,

    // This means that you change your real URL (current PHP url) 
    // to another URL (which Live Sever starts).
    "liveServer.settings.proxy": {
        "enable": true,                             //   i. enabled
        "baseUri": "/",                             //  ii. workspace
        "proxyUri": "http://localhost:80/fleetio" // iii. actual address
    },
    "editor.cursorStyle": "line",
    "editor.insertSpaces": false,
    "editor.wordSeparators": "/\\()\"':,.;<>~!@#$%^&*|+=[]{}`?-",
    "editor.wordWrap": "off",
    "security.workspace.trust.untrustedFiles": "open",
    "editor.tabCompletion": "on",
    "files.exclude": {
        "app/Support/firebase": true
    },
    "editor.suggest.snippetsPreventQuickSuggestions": false,
    "editor.find.seedSearchStringFromSelection": "never",
    "diffEditor.ignoreTrimWhitespace": false,
}
```