# VSCODE TRICKS

### 1) How to add xdebug in visual studio code

```jsx
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
    
        {
            "name": "Launch Built-in server",
            "type": "php",
            "request": "launch",
            "port": 9000,
        }
        
        
    
    ]
}
```

Note: Filename is launch.json

### 2) Remove spaces in VSCODE

```jsx
^(\s)*$\n 
```

### 3) Vim setup in vscode

```jsx
[
    {
        "key":"tab",
        "command":"tab",
        "when":"editorTextFocus && !editorTabMovesFocus",
    },
    {
        "key":"shift+tab",
        "command":"outdent",
        "when":"editorTextFocus && !editorTabMovesFocus",                     
    },
]
```

```jsx
Note: THis file is edited in keybindings.json
```

```jsx
true,
    "vim.useCtrlKeys": true,
    "vim.hlsearch": true,
    "vim.insertModeKeyBindings": [
        {
        "before": ["k", "j"],
        "after": ["<Esc>"]
        }
    ],
    "vim.normalModeKeyBindingsNonRecursive": [
        // {
        //     "before": [
        //         "<leader>",
        //         "d"
        //     ],
        //     "after": [
        //         "d",
        //         "d"
        //     ]
        // },
        {
            "before": [
                "<leader>",
                "d"
            ],
            "after": [
                "\"",
                "_",
                "d",
            ]
        }, 
        {
            "before": ["<leader>", "p"],
            "commands": [
                "workbench.action.showCommands",
            ]
        },
        {
            "before": ["<leader>", "f"],
            "commands": [
                "workbench.action.quickOpen",
            ],
        },
        {
            "before": ["<leader>", "o"],
            "commands": [
                "workbench.action.gotoSymbol",
            ]
        },
        {
            "before": ["<leader>", "t"],
            "commands": [
                "vim.showQuickpickCmdLine"
            ]
        },
        {
            "before": ["<leader>", "b"],
            "commands": [
            "open-buffers.openBuffer"
            ]
        },
        {
            "before": ["t", "t"],
            "after": [":"]
        },
        {
            "before": ["t", "t", "w", "<Enter>"],
            "after": ["g","g","=","G","<C-o>"]
        },
        {
            "before": ["<leader>", "c", "f"],
            "after": ["V","j","%","y"]
        },
        // {
        // "before": ["<C-n>"],
        // "commands": [":nohl"]
        // }
    ],
		"vim.visualModeKeyBindingsNonRecursive": [
        {
            "before": [
                "p",
            ],
            "after": [
                "p",
                "g",
                "v",
                "y"
            ]
        }
    ],
    "vim.leader": "<space>",
    "vim.smartcase": false,
    "vim.handleKeys": {
        "<C-a>": false,
        "<C-f>": false,
        "<C-c>": false,
        "<C-v>": false,
        "<C-x>": false,
        "<C-w>": false,
        "<C-h>": false
    },
```

```jsx
Note: This file is in settings.json
```

### 4) Back up Settings.JSON file

[Backup Settings.JSON file](VSCODE%20TRICKS%20c5d4e7c38018457bbc8c4b99bd187df4/Backup%20Settings%20JSON%20file%20913ca809441e41a7b4d5bc8e9d33363b.md)

### 5) keybinding.JSON

[Keybinding.JSON file](VSCODE%20TRICKS%20c5d4e7c38018457bbc8c4b99bd187df4/Keybinding%20JSON%20file%20ed6e9c6c56984a8cb3be4ccfcc4ff187.md)

### 6) How to Create User snippets

```jsx
{
	// Place your snippets for php here. Each snippet is defined under a snippet name and has a prefix, body and 
	// description. The prefix is what is used to trigger the snippet and the body will be expanded and inserted. Possible variables are:
	// $1, $2 for tab stops, $0 for the final cursor position, and ${1:label}, ${2:another} for placeholders. Placeholders with the 
	// same ids are connected.
	// Example:
	// "Print to console": {
	// 	"prefix": "log",
	// 	"body": [
	// 		"console.log('$1');",
	// 		"$2"
	// 	],
	// 	"description": "Log output to console"
	// }
	"Pre": {
		"prefix": "pre",
		"body": [
			"echo \"<pre>\";",
			"print_r($1);die;",
		],
		"description": "Pre tag with Print R following die"
	},
}
```

```jsx
Note: cntrl+shift+p (configure user snippet)
```

7) Extensions used in vscode

[Extensions](VSCODE%20TRICKS%20c5d4e7c38018457bbc8c4b99bd187df4/Extensions%208d1b69f20eed4a489c176ef3193ca7c8.md)