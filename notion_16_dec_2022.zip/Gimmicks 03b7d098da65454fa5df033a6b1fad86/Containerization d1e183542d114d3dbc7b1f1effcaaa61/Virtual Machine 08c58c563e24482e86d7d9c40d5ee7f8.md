# Virtual Machine

[QEMU (Fast virtual machine for linux)](Virtual%20Machine%2008c58c563e24482e86d7d9c40d5ee7f8/QEMU%20(Fast%20virtual%20machine%20for%20linux)%201c638364f6324ebdb6d0e6bd98f6e8a9.md)

[Increase QEMU KVM virtual disk size](Virtual%20Machine%2008c58c563e24482e86d7d9c40d5ee7f8/Increase%20QEMU%20KVM%20virtual%20disk%20size%201d096fc3c1794202bd97137c7b19c56d.md)

[QEMU Manual Insallation](Virtual%20Machine%2008c58c563e24482e86d7d9c40d5ee7f8/QEMU%20Manual%20Insallation%200b43738cb4ec4c10a2bdd3c7e584339a.md)