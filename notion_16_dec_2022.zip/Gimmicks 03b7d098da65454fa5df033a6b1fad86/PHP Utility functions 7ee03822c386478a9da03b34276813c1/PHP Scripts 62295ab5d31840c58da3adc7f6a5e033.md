# PHP Scripts

1) Date Difference in days

[date_difference.sh](PHP%20Scripts%2062295ab5d31840c58da3adc7f6a5e033/date_difference%20sh%201d5b43fc232d4f6dbb6b4737bda86042.md)

2) convert timestamp to date

[timestamp.sh](PHP%20Scripts%2062295ab5d31840c58da3adc7f6a5e033/timestamp%20sh%20bbc4074ab485480fab19277c1aaafdf0.md)

3) convert date to timestamp

[date_to_timestamp.sh](PHP%20Scripts%2062295ab5d31840c58da3adc7f6a5e033/date_to_timestamp%20sh%20443aa2c26b7e42eca2191445c832415c.md)