# Neovim minimum init.lua

```bash
nvim
├── init.lua
├── lua
│   └── core
│       ├── keymaps.lua
│       ├── plugin_config
│       │   ├── gruvbox.lua
│       │   ├── hop.lua
│       │   ├── init.lua
│       │   ├── lspconfig.lua
│       │   ├── lualine.lua
│       │   ├── mason.lua
│       │   ├── nvim_cmp.lua
│       │   ├── nvim-tree.lua
│       │   ├── telescope.lua
│       │   ├── treesitter.lua
│       │   └── wilder.lua
│       └── plugins.lua
└── plugin
    └── packer_compiled.lua

4 directories, 15 files
```

1) init.lua

```bash
require("core.keymaps")
require("core.plugins")
require("core.plugin_config")
```

2) lua/core

2.1) lua/core/keymaps.lua

```bash
vim.g.mapleader = ' '
vim.g.maplocalleader = ' '
--use kj as esc
local options = { noremap = true }
vim.keymap.set("i", "kj", "<Esc>", options)
--use space and tabs
vim.opt.tabstop=4
vim.opt.shiftwidth=4
vim.opt.shiftround=true
vim.opt.expandtab=true

--hop plugin keymap
vim.keymap.set("n", "<leader>h", "<cmd>HopWord<cr>", options)
```

2.2) lua/core/plugins.lua

```bash
local ensure_packer = function()
  local fn = vim.fn
  local install_path = fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
  if fn.empty(fn.glob(install_path)) > 0 then
    fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
    vim.cmd [[packadd packer.nvim]]
    return true
  end
  return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'
  use 'ellisonleao/gruvbox.nvim'
  use 'nvim-tree/nvim-tree.lua'
  use 'nvim-tree/nvim-web-devicons'
  use 'nvim-lualine/lualine.nvim'
  use 'nvim-treesitter/nvim-treesitter'
  use 'williamboman/mason.nvim'
  use 'williamboman/mason-lspconfig.nvim'
  use 'neovim/nvim-lspconfig'
  use {
      'hrsh7th/cmp-nvim-lsp',
      'hrsh7th/cmp-buffer',
      'hrsh7th/nvim-cmp'
  }
  use {
      'nvim-telescope/telescope.nvim',
      tag = '0.1.0',
      requires = { {'nvim-lua/plenary.nvim'} }
  }
  use {
      'nvim-telescope/telescope-fzf-native.nvim',
      run = "make"
  }
  use 'L3MON4D3/LuaSnip'
  use 'saadparwaiz1/cmp_luasnip'

  use 'phaazon/hop.nvim'
  use 'gelguy/wilder.nvim' -- autocomplete in command line, search :updateremoteplugins if python not worked
  use 'SirVer/ultisnips'  -- python3 -m pip install --user --upgrade pynvim
  use 'honza/vim-snippets'

 
  -- My plugins here
  -- use 'foo1/bar1.nvim'
  -- use 'foo2/bar2.nvim'

  -- Automatically set up your configuration after cloning packer.nvim
  -- Put this at the end after all plugins
  if packer_bootstrap then
    require('packer').sync()
  end
end)
```

3) lua/core/plugin_config

3.1) lua/core/plugin_conifg/gruvbox.lua

```bash
vim.o.termguicolors = true
vim.cmd [[ colorscheme gruvbox ]]
```

3.2) lua/core/plugin_conifg/init.lua

```bash
require("core.plugin_config.gruvbox")
require("core.plugin_config.nvim-tree")
require("core.plugin_config.lualine")
require("core.plugin_config.treesitter")
require("core.plugin_config.telescope")
require("core.plugin_config.mason")
require("core.plugin_config.lspconfig")
require("core.plugin_config.nvim_cmp")
require("core.plugin_config.hop")
require("core.plugin_config.wilder")
```

3.3) lua/core/plugin_conifg/lualine.lua

```bash
require('lualine').setup {
    options = {
        icons_enabled =true,
        theme = gruvbox,
    },
    sections = {
        lualine_a = {
            {
                'filename',
                path = 1,
            }
        }
    }
}
```

3.4) lua/core/plugin_conifg/nvim-tree.lua

```bash
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
require("nvim-tree").setup()
vim.keymap.set('n','<c-n>',':NvimTreeFindFileToggle<CR>')
```

3.5) lua/core/plugin_conifg/telescope.lua

```bash
local ok, telescope=pcall(require, "telescope")
if not ok then
    return
end
telescope.setup()
require('telescope').load_extension('fzf')
local builtin = require('telescope.builtin')

vim.keymap.set('n','<Space>ff' , builtin.find_files , {})
vim.keymap.set('n','<Space>fk' , builtin.oldfiles , {})
vim.keymap.set('n','<Space>fo' , builtin.live_grep, {})
vim.keymap.set('n','<Space>ft' , builtin.help_tags, {})
vim.keymap.set('n','<Space>fg' , builtin.git_files, {})
```

3.6) lua/core/plugin_conifg/treesitter.lua

```bash
require 'nvim-treesitter.configs'.setup {
    -- a list of parser names or all
    ensure_installed= {"c", "lua" , "rust", "ruby", "vim", "python" , "php"},
    -- Install parsers synchronously (only applied to ensure_installe)
    sync_install = false,
    auto_install = true,
    highlight = {
        enable = true,
    },
}
```

3.7) lua/core/plugin_conifg/hop.lua

```bash
require'hop'.setup()
```

3.8) lua/core/plugin_conifg/lspconfig.lua

```bash
-- Mappings.
-- See `:help vim.diagnostic.*` for documentation on any of the below functions
local opts = { noremap=true, silent=true }
vim.keymap.set('n', '<space>e', vim.diagnostic.open_float, opts)
vim.keymap.set('n', '[d', vim.diagnostic.goto_prev, opts)
vim.keymap.set('n', ']d', vim.diagnostic.goto_next, opts)
vim.keymap.set('n', '<space>q', vim.diagnostic.setloclist, opts)

-- Use an on_attach function to only map the following keys
-- after the language server attaches to the current buffer
local on_attach = function(client, bufnr)
  -- Enable completion triggered by <c-x><c-o>
  vim.api.nvim_buf_set_option(bufnr, 'omnifunc', 'v:lua.vim.lsp.omnifunc')

  -- Mappings.
  -- See `:help vim.lsp.*` for documentation on any of the below functions
  local bufopts = { noremap=true, silent=true, buffer=bufnr }
  vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, bufopts)
  vim.keymap.set('n', 'gd', vim.lsp.buf.definition, bufopts)
  vim.keymap.set('n', 'K', vim.lsp.buf.hover, bufopts)
  vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, bufopts)
  vim.keymap.set('n', '<C-k>', vim.lsp.buf.signature_help, bufopts)
  vim.keymap.set('n', '<space>wa', vim.lsp.buf.add_workspace_folder, bufopts)
  vim.keymap.set('n', '<space>wr', vim.lsp.buf.remove_workspace_folder, bufopts)
  vim.keymap.set('n', '<space>wl', function()
    print(vim.inspect(vim.lsp.buf.list_workspace_folders()))
  end, bufopts)
  vim.keymap.set('n', '<space>D', vim.lsp.buf.type_definition, bufopts)
  vim.keymap.set('n', '<space>rn', vim.lsp.buf.rename, bufopts)
  vim.keymap.set('n', '<space>ca', vim.lsp.buf.code_action, bufopts)
  vim.keymap.set('n', 'gr', vim.lsp.buf.references, bufopts)
  vim.keymap.set('n', '<space>f', function() vim.lsp.buf.format { async = true } end, bufopts)
end
-- enable lsp capabilities
local capabilities = vim.lsp.protocol.make_client_capabilities()
capabilities.textDocument.completion.completionItem.snippetSupport = true
capabilities.textDocument.completion.completionItem.resolveSupport = {
  properties = {
    'documentation',
    'detail',
    'additionalTextEdits',
  }
}

local lsp_flags = {
  -- This is the default in Nvim 0.7+
  debounce_text_changes = 150,
}
require('lspconfig')['intelephense'].setup{
    on_attach = on_attach,
    capabilities = capabilities,
    flags = lsp_flags,
}
```

3.9) lua/core/plugin_conifg/nvim_cmp.lua

```bash
-- autocomplted configuration of lsp (new)
local nvim_lsp = require('lspconfig')
vim.opt.completeopt = {'menu', 'menuone', 'noselect'}

require('luasnip.loaders.from_vscode').lazy_load()
require("luasnip.loaders.from_snipmate").load({ include = { "php" } }) --for snippets to work need to install vim-snippets plugin

local cmp = require('cmp')
local luasnip = require('luasnip')

local select_opts = {behavior = cmp.SelectBehavior.Select}

cmp.setup({
  snippet = {
    expand = function(args)
      luasnip.lsp_expand(args.body)
    end
  },
  sources = {
	{name = 'luasnip', keyword_length = 2},
    {name = 'path'},
    {name = 'nvim_lsp', keyword_length = 3},
    {name = 'buffer', keyword_length = 3},
  },
  window = {
    documentation = cmp.config.window.bordered()
  },
  formatting = {
    fields = {'menu', 'abbr', 'kind'},
    format = function(entry, item)
      local menu_icon = {
        nvim_lsp = 'λ',
        luasnip = '⋗',
        buffer = 'Ω',
        path = '',
      }

      item.menu = menu_icon[entry.source.name]
      return item
    end,
  },
  mapping = {
    ['<Up>'] = cmp.mapping.select_prev_item(select_opts),
    ['<Down>'] = cmp.mapping.select_next_item(select_opts),

    ['<C-p>'] = cmp.mapping.select_prev_item(select_opts),
    ['<C-n>'] = cmp.mapping.select_next_item(select_opts),

    ['<C-u>'] = cmp.mapping.scroll_docs(-4),
    ['<C-f>'] = cmp.mapping.scroll_docs(4),

    ['<C-e>'] = cmp.mapping.abort(),
    ['<CR>'] = cmp.mapping.confirm({select = true}),

    ['<C-d>'] = cmp.mapping(function(fallback)
      if luasnip.jumpable(1) then
        luasnip.jump(1)
      else
        fallback()
      end
    end, {'i', 's'}),

    ['<C-b>'] = cmp.mapping(function(fallback)
      if luasnip.jumpable(-1) then
        luasnip.jump(-1)
      else
        fallback()
      end
    end, {'i', 's'}),

    ['<Tab>'] = cmp.mapping(function(fallback)
      local col = vim.fn.col('.') - 1

      if cmp.visible() then
        cmp.select_next_item(select_opts)
      elseif col == 0 or vim.fn.getline('.'):sub(col, col):match('%s') then
        fallback()
      else
        cmp.complete()
      end
    end, {'i', 's'}),

    ['<S-Tab>'] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_prev_item(select_opts)
      else
        fallback()
      end
    end, {'i', 's'}),
  },
})
```

3.10) lua/core/plugin_conifg/wilder.lua

```bash
local wilder = require('wilder')
wilder.setup({modes = {':', '/', '?'}})
```

3.11) lua/core/plugin_conifg/mason.lua

```bash
require("mason").setup({
    ui = {
        icons = {
            package_installed = "✓",
            package_pending = "➜",
            package_uninstalled = "✗"
        }
    }
})
require("mason-lspconfig").setup()
```