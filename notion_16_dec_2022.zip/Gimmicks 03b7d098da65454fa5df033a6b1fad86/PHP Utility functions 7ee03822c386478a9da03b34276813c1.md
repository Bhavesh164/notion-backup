# PHP Utility functions

# 1) Time Elapsed Comments (For e.g. less than year ago)

```php
function time_elapsed_string($datetime, $full = false)
{
  $now = new DateTime;
  $ago = new DateTime($datetime);
  $diff = $now->diff($ago);

  $diff->w = floor($diff->d / 7);
  $diff->d -= $diff->w * 7;

  $string = array(
      'y' => 'year',
      'm' => 'month',
      'w' => 'week',
      'd' => 'day',
      'h' => 'hour',
      'i' => 'minute',
      's' => 'second',
  );
  foreach ($string as $k => &$v) {
      if ($diff->$k) {
          $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
      } else {
          unset($string[$k]);
      }
  }

  if (!$full) $string = array_slice($string, 0, 1);
  return $string ? implode(', ', $string) . ' ago' : 'just now';
}
```

2) PHPminiAdmin (For fast access on browser)

[phpminiadmin.php](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/phpminiadmin%20php%20f5111d51a21148359a7ae9bd67c6c926.md)

[PHP Pagination](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/PHP%20Pagination%203ccbe381aead46d9bd849e068ebac3be.md)

3) How to add Cron job in PHP

```jsx
curl --silent "https://lechatservices.com/admin/cron/send_result" >/dev/null 2>&1
```

4) Laravel

[Laravel](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/Laravel%202bb7e79ef1474427ac63dcc690843336.md)

5) How to sort multi dimensional array

```jsx
$keys = array_column($data, 'count');
array_multisort($keys, SORT_DESC, $data);
```

6) How to run apache benchmarking in LInux 

```jsx
ab -n 1000 -c 100 https://demo.aed365.com/aed365-web/user-management
```

7) Get days between two dates

```jsx
$start_date=time();
$end_date=$value->end_date;
$start_date=date('Y-m-d',$start_date);
$end_date=date('Y-m-d',$end_date);
$earlier = new \DateTime($start_date);
$later = new \DateTime($end_date);
$abs_diff = $later->diff($earlier)->format("%a");
```

8) Switch PHP version in ngnix in Ubuntu 20.04 linux

```jsx
sudo update-alternatives --config php
```

9) quickly test a mail in laravel

```jsx
php artisan tinker
>> Mail::raw('Hello World!', function($msg) {$msg->to('myemail@gmail.com')->subject('Test Email'); });
```

10) PHP Scripts

[PHP Scripts](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/PHP%20Scripts%2062295ab5d31840c58da3adc7f6a5e033.md)

11) Run PHP as server using PHP only

```jsx
php -S localhost:8000 -t /directory
```

12) 

[How to enable virtual host in ubuntu](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/How%20to%20enable%20virtual%20host%20in%20ubuntu%20fb357aa4284f4e74adb58cd518a724db.md)

13) 

[Run PHP using nginx](PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1/Run%20PHP%20using%20nginx%20574abb892d3e43319104eabf308a1012.md)