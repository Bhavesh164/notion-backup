# Powershell

1) show Wi-Fi profiles

```jsx
netsh wlan show profiles
Note: It will list all the profiles
```

2) Show Password of Wi-Fi network profiles

```jsx
netsh wlan show profile Vikas key=clear (where Vikas is profile name)
```

3) Show PowerShell alias directory

```jsx
echo $profile/..   (we have to create profile.ps1 file)
```

4) some PowerShell alias examples

```jsx
Invoke-Expression (& { (lua "C:\Program Files (x86)\clink\1.2.35.fa2a3e\z.lua" --init powershell) -join "`n" })
function fzf_directory(){ cd (fd -t d -X printf "%s/\n" '{}' | sed "s/]/``]/g" | sed "s/\[/``[/g"  | fzf) }
New-Alias zz fzf_directory
function one_directory_back{cd ..}
New-Alias .. one_directory_back
function two_directory_back{cd ../..}
New-Alias ... two_directory_back
```