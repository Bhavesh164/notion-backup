# Bash Scripts

1) Bookmark using fzf bash script

[bookmark.sh](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/bookmark%20sh%207de66f2d659745e3a3c5568a545d6451.md)

2) Switch git braches using fzf

[gitbranch.sh](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/gitbranch%20sh%20d4e87a155b01479e978ba97b2086cfa7.md)

3) Switch directories using fzf with flags

[fzf_directories.sh](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/fzf_directories%20sh%20914768e394f6475bab8ffe16bc6080f2.md)

4) MPV wiht fzf

[mpv_with_fzf.sh](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/mpv_with_fzf%20sh%20f764213e8a5c4c83916c0a667f2b857f.md)

5) config files using bash scripts

[Config file using Bash Scripts](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Config%20file%20using%20Bash%20Scripts%20c39dbbc3748b4ec3a7f4d525b2da201f.md)

6) Ueberzug to display images in terminal

[Ueberzug script](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Ueberzug%20script%20794f7978d97a4b9983d201c131d335e7.md)

7) Screen record script using ffmpeg

[Screen Recording](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Screen%20Recording%20e595d43c2ff04995b2b33013ca61a6f4.md)

8) Simple dmenu script

[Dmenu](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Dmenu%20962eaacf111e4e29bd7ce0709bfb29e5.md)

9) Functions with menus

[Functions with menu](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Functions%20with%20menu%20722b2baece0b474a9f328a1dc019ac07.md)

10) quickly send a file using https://[0x0.st](http://0x0.st) utility 

[Quickly send a file ](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Quickly%20send%20a%20file%20bd49c4aa0c1a4fd280e04cdac10d19eb.md)

11) Set wallpapers using sxiv

[set wallpapers using sxiv](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/set%20wallpapers%20using%20sxiv%2022fcbdc8657b4f2ea043578fde2af77a.md)

12) Handling errors

[Handling Errors](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Handling%20Errors%20442a09b51851497f9597a1b7cb47fc27.md)

13) set wallpaper using sxiv key-handler

[Set wallpaper using sxiv key-handler](Bash%20Scripts%2085ee4bf683564dd0840f2f8a50f55c0b/Set%20wallpaper%20using%20sxiv%20key-handler%20bd4c7790872f423ba33e5e44fbb21083.md)