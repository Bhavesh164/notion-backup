# Youtube Downloader

1) make youtube dowload with aria2c

```jsx

yt-dlp -f best --external-downloader aria2c --external-downloader-args "-j 16 -x 16 -s 16 -k 1M" https://www.youtube.com/watch?v=iqMRu21OFqE https://www.youtube.com/watch?v=h4vmU2DJoQg
```