# 79) How to create a permanent alias

**For non-login shells**

```bash
sudo vim /etc/bash.bashrc
put aliases in these file
alias vim='nvim' (do not run sudo it will not work)
```

**This method is for login shells**

You can create a script in `/etc/profile.d/` to make aliases for all users:

1. Create a file called `00-aliases.sh` (or any other fancy name) in `/etc/profile.d`:
    
    ```
    gksu gedit /etc/profile.d/00-aliases.sh
    
    ```
    
2. Put you aliases in this file. Example:
    
    ```
    alias foo='bar --baz'
    alias baz='foo --bar'
    
    ```
    
3. Save the file
4. Restart any open terminals to apply the changes.
5. Enjoy!

---

**Some notes:**

- `/etc/profile` is a global file that gets run before `~/.profile`.
- `/etc/profile.d/` is a folder that contains scripts called by `/etc/profile`
- When `/etc/profile` is called (when you start/login a shell), it searches for any files ending in `.sh` in `/etc/profile.d/` and runs them with one of these commands:
    
    ```
    source /etc/profile.d/myfile.sh
    
    ```
    
    ---
    
    ```
    . /etc/profile.d/myfile.sh
    
    ```
    
- I'm putting `00-` before the file name to make it execute before the rest of the scripts.
- You can also add your aliases in `/etc/profile`, but this isn't recommended.