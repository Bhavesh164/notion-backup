# set wallpapers using sxiv

```bash
#!/usr/bin/env bash
sxiv -r -q -o * | xargs -I {} gsettings set org.gnome.desktop.background picture-uri "$PWD/{}"
```