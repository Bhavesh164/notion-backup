# Dmenu

```bash
#!/usr/bin/env bash

chosen=$(ls | dmenu -i)
exec $chosen
```