# Linux commands

1) List out the packages in linux

```
dpkg -l | wc -l
```

2) wget

```
wget \
 --recursive \
 --no-clobber \
 --page-requisites \
 --html-extension \
 --convert-links \
 --restrict-file-names=unix \
 --domains docs.scrapy.org \
 --wait=5 \
 --limit-rate=20K \
 --user-agent=Mozilla \
 --level=10 \
 --output-file /home/melvin/test/activity.txt \
 --no-parent \
 https://docs.scrapy.org/en/latest/ &
```

3) Run windows programs in WSL 2

```
mpv.exe file_name (to run mpv player)
explorer.exe (to open windows explorer)
```

4) Backup .bashrc

[.bashrc](Linux%20commands%20ca1bf250956b4c7b8156481ebc52636f/bashrc%20840e1008dd2c4bb1a38a20b005cfb41c.md)

5) Backup .inputrc file (This file is ued for overriding default keymappings (it shoudl be contained in home folder)

```jsx
$include /etc/inputrc
set completion-ignore-case On
"\\C-h": backward-kill-word

```

6) Expand current directory in vim

```jsx
%:h/
for e.g (:vsp %:h)

```

7) mlterm (is terminal that supports text based browser and colors)

```jsx
mlterm -fg white -bg black

```

8) How to mount external USB drive in WSL

```jsx
1) cd /mnt
2) sudo mkdir g
3) sudo mount -t drvfs g: /mnt/g
4) sudo umount g
5) sudo rmdir g

```

9) How to automount drive in linux

```jsx
# first list the drivers by following command
1) sudo blkid
# Then go to the following directory
2) sudo /etc/fstab
# edit the file
3) UID=01D73EBA58012C30   /mnt/files      ntfs    defaults        0       0
#make sure spces are separated by tabs
```

10) Map Caps Lock to Esc key

```jsx
1) cd /etc/default
2) vim keyboard
note: edit the file add the following line
XKBOPTIONS="caps:swapescape"
```

11) Connect Wifi in terminal using script (need dmenu)

```jsx
#!/bin/sh
bssid=$(nmcli device wifi list | sed -n '1!p' | cut -b  9- | dmenu -p "Select wifi:" -l 20 | cut -d' ' -f1)
pass=$(echo "" | dmenu -p "Enter Password: ")
nmcli device wifi connect $bssid password $pass
```

12) Fix screen tearing in Linux for Intel machines

```jsx
go to etc/X11/xorg.conf.d/20-intel.conf
add the following lines in above files

Section "Device"

    Identifier "Intel Graphics"

    Driver "intel"

    Option "TearFree" "true"

EndSection

```

13) Create a new tmux session using command inside tmux

```jsx
:new -s "hello"
```

14) Upload multiple files using curl

```jsx
curl -F 'files[]=@/path/to/fileX' -F 'files[]=@/path/to/fileY' ... http://localhost/upload
```

15) Download website using Wget

```jsx
wget -m google.com
(where m stands for mirror)
```

16) you can check metadata of file using

```jsx
exiftool
```

17) Compile c++ programs

```jsx
g++ hello.C -o hello.o (there is second command also)
make hello (without extension)
```