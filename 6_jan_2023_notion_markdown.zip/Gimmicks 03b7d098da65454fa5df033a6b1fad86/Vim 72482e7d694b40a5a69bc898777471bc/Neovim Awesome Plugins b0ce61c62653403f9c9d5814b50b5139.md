# Neovim Awesome Plugins

1. [emmylua-nvim](https://github.com/ii14/emmylua-nvim): Improve the completion experience for Neovim APIs.
2. [nvim-notify](https://github.com/rcarriga/nvim-notify): Modern notification.
3. [lush.nvim](https://github.com/rktjmp/lush.nvim): Customize and compile color theme.
4. [hlargs.nvim](https://github.com/m-demare/hlargs.nvim): Highlight arguments of function/method, because some language servers don't support semantic tokens.
5. [iswap.nvim](https://github.com/mizlan/iswap.nvim): Swap argument with treesitter.
6. [Comment.nvim](https://github.com/numToStr/Comment.nvim): Comment code, support injection language with treesitter.
7. [neogen](https://github.com/danymat/neogen): Use treesitter parser to generate annotation, and use extmark for placeholders to jump.
8. [nvim-gdb](https://github.com/sakhnik/nvim-gdb): GDB wrapper, simple and easy to hack.
9. [matchparen.nvim](https://github.com/monkoose/matchparen.nvim): Fast match parenthesis and has handled folded condition.
10. [gitsigns.nvim](https://github.com/lewis6991/gitsigns.nvim): High performance git gutter with `word_diff` feature.
11. [nvim-hlslens](https://github.com/kevinhwang91/nvim-hlslens): Humanized UI for search results with high performance, I'm the author.
12. [nvim-bqf](https://github.com/kevinhwang91/nvim-bqf): Integrate `fzf` inside quickfix, preview with high performance and stabilize quickfix window, I'm the author.
13. [nvim-ufo](https://github.com/kevinhwang91/nvim-ufo): Fast and modern fold, AFAIK, the best fold plugin. I'm the author.
14. [rnvimr](https://github.com/kevinhwang91/rnvimr): Integrate `ranger` inside Neovim seamlessly, I'm the author.
15. [nvim-treesitter](https://github.com/nvim-treesitter/nvim-treesitter): Fast and modern syntax highlighting, replace Vim regex syntax.
16. [packer.nvim](https://github.com/wbthomason/packer.nvim): Plugin manager, use `packadd` mechanism and support `luarocks`.

List the plugins I'm using and explain why I use them. The features of plugins are all missing in Vim.