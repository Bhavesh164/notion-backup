# VIMRC FILE

```jsx
set ruler
set number
syntax enable
color slate
if has("gui_running")
  " Set a nicer font.
  set guifont=Consolas:h11:cDEFAULT
  " Hide the toolbar.
  set guioptions-=T
endif
" cd /xampp/htdocs
autocmd GUIEnter * simalt ~x
:silent! TroublesomeCommand
inoremap kj <Esc>
nnoremap tt :
set backspace=indent,eol,start
set nocompatible
set path+=**
:set path=.,,** "current directory search with tabfind
set wildmenu
:set wildignorecase
:set tabstop=4
:set shiftwidth=4
:set autoindent
:set smartindent
:set number
:set hidden
:set foldmethod=indent   
:set foldnestmax=10
:set nofoldenable
:set foldlevel=10 " if not set it will fold entire region first time
:set ignorecase
:set mouse=a
:set splitright
set clipboard=unnamedplus
set iskeyword+=-
set iskeyword+=_
:filetype plugin on
call plug#begin('~/.vim/plugged')
" Other plugins here.
Plug 'ctrlpvim/ctrlp.vim'
Plug 'vim-scripts/AutoComplPop'
Plug 'mattn/emmet-vim'
Plug 'prettier/vim-prettier', {
  \ 'do': 'yarn install',
  \ 'for': ['javascript', 'typescript', 'css', 'less', 'scss', 'json', 'graphql', 'markdown', 'vue', 'yaml', 'html', 'php'] }
Plug 'Yggdroot/indentLine'
Plug 'tomtom/tcomment_vim'
Plug 'SirVer/ultisnips' | Plug 'honza/vim-snippets'
Plug 'sindrets/diffview.nvim'
Plug 'ronakg/quickr-preview.vim'
Plug 'preservim/tagbar'
Plug 'tommcdo/vim-exchange'
Plug 'godlygeek/tabular'
Plug 'tpope/vim-abolish' " convert into upper,snake case 
Plug 'junegunn/fzf'
Plug 'junegunn/fzf.vim'
Plug 'gelguy/wilder.nvim' "autocomplete in command line, search
Plug 'Bhavesh164/vim-cpp'
Plug 'Bhavesh164/cool-vim'
Plug 'wellle/context.vim' "sticky function header
Plug 'tpope/vim-fugitive'
Plug 'tpope/vim-unimpaired' " browse quick fix list using [q ]q
Plug 'RRethy/vim-illuminate' " highlight vairables
Plug 'adinapoli/vim-markmultiple' " cntrl+n to select a word
Plug 'AndrewRadev/deleft.vim' "dh keybinding to delete blocks like if/ try,catch, div
Plug 'AndrewRadev/tagalong.vim' " rename a html tag
Plug 'AndrewRadev/multichange.vim' "mark multiple advanced version
Plug 'AndrewRadev/splitjoin.vim'  " bindings are gJ and gS
Plug 'brooth/far.vim' "modern find and replace
Plug 'mbbill/undotree' "undo tree
call plug#end()
:inoremap <C-BS> <C-W>
set tabstop=4
:set shiftwidth=4
:set autoindent
:set smartindent
" Emmet Shortcuts
let g:user_emmet_mode='n' "only enable normal mode functions
let g:user_emmet_leader_key=','
:let &pythonthreedll = 'C:\Users\bhaveshverma\AppData\Local\Programs\Python\Python39\python39.dll'
autocmd filetype php set filetype=php.html

" fzf ripgrep
nnoremap <leader>g :Rg!

" tag bar configuartions
nmap <F8> :TagbarToggle<CR>

"wilder nvim minimal config
call wilder#setup({'modes': [':', '/', '?']})

" center the cursor 
autocmd CursorMoved,CursorMovedI * call Center_cursor()

function! Center_cursor()
    let pos = getpos(".")
    normal! zz
    call setpos(".", pos)
endfunction

" indentation jumping, sometimes useful
noremap <silent> <M-k> :call search('^'. matchstr(getline('.'), '\(^\s*\)') .'\%<' . line('.') . 'l\S', 'be')<CR>
noremap <silent> <M-j> :call search('^'. matchstr(getline('.'), '\(^\s*\)') .'\%>' . line('.') . 'l\S', 'e')<CR>

"function to get new line with semi colon

fun! NewLine()
    let l:save = winsaveview()
	keeppatterns '<,'>s/;/&\r/g | norm dd
    call winrestview(l:save)
endfun

"set color scheme after plugin is initialized
set termguicolors
colorscheme onedark

"undo tree configuration
if has("persistent_undo")
   let target_path = expand('~/programs/undodirectory')

    " create the directory and any parent directories
    " if the location does not exist.
    if !isdirectory(target_path)
        call mkdir(target_path, "p", 0700)
    endif

    let &undodir=target_path
    set undofile
endif
```