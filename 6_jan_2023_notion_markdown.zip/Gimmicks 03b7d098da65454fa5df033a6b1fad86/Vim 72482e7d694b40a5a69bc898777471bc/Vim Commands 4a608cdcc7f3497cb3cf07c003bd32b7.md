# Vim Commands

1) How to create a file in current directory in vim

```jsx
:w %:h/filename.php   (where % is current file and :h means current upto current directory)
```

2) Create a new file and switch to a new file

```jsx
:sav %:h/my-new-file.ts
```

3) Delete a file in vim

```jsx
rm
```

4) Commands mode in vim guide

```jsx
https://alldrops.info/posts/vim-drops/2018-05-15_understand-vim-mappings-and-create-your-own-shortcuts/
```

5) To unfold all

```jsx
zR (where R is capital letter)
```

6) Vimgrep

```jsx
:vimgrep /function /g %   (where % is current buffer only)
:copen (showing vimgrep result)
:cclose (close quickfix list)
:vimgrep /text/ path_to_dir/*
```

7) Two beautiful help command in vim

```jsx
1) :help motion.txt 2) :help index.txt
```

8) Set clipboard to system clipboard

```jsx
:set clipboard=unnamedplus
```

9) Blackhole register in Vim

```jsx
<leader>d "_d  (undersocre is blackhole register use to delete without clipboard) 
Note: you should press <leader>dd (d twice to function properly)
```

10) Searching in whole project with vimgrep in Vim

```jsx
vim /search/g **/*   (**/* means whole project)
vim /serach/g . (. means current directory)
```

11) How to paste text in search mode (/ mode)

```jsx
1) yank the text
press q/pEnter
q/: open the search history

pEnter: paste the yanked text on the command line and search

2) /<C-r>0 (0 is most yanked register)
if you want to copy from system clipboard then command is
/<C-r>+ (+ is clipboard register and <C-r> is Control+R)

```

12) How to search text in Visual selection mode

```jsx
/text\%V  (\%V is used for search in visual selection)
```

[Trim whitespaces Detailed Explanation](Vim%20Commands%204a608cdcc7f3497cb3cf07c003bd32b7/Trim%20whitespaces%20Detailed%20Explanation%206e25aff7fbb144d1b99a16d3733fe763.md)

13) Removing trailing white spaces in vim 

```jsx
:%s/\s\+$//e
```

14) How to search without leaving search mode.

```jsx
/search (press cntrl+g to search forwars, cntrl+t to search backwards without leaving search mode
```

15) Scroll two splits simultaneously in Vim with :set scrollbind or toggle with :set scb! Useful for comparing two files.

```jsx
:set scrollbind
:set scb! (for toggle)
```

16) How to find the word in all files using native vim

```jsx
:vimgrep /button/jg ./**/*.js   (it will fetch the records in quickfix list)
:cw (open quick-fix list)
```

17) Configure merge tool in git

```jsx
git config --global merge.tool vimdiff
diffo (turn off diff)
difft (turn on diff)
diffu (diff update)
diffg 1 (getting your changes)
:hi DiffText guibg=darkred (hi stands for highlight)
:hi DiffText ctermbg=darkred (cterm is for terminal)
```

18) Close all buffers in vim

```jsx
bufdo bd
```

19) Switch between recent buffers

```jsx
Cntrl+6 (switch between buffers)
or
:b#
```

20) search the only word in vim

```jsx
/\v<word>   (\v stands for very magic, <> is defined as word boundries)
```

21) Entire undo in vim buffer

```jsx
:u0  (where 0 is zero)
```

22) undo since last write

```jsx
:e!
```

23) Search in vim without leaving search mode

```jsx
cntrl+g (moving forward)
cntrl+t (moving backward)
```

24) Enable or disable a command in init.vim or .vimrc

```jsx
let g:toggle = 0
function CopilotToggle(toggle)
if g:toggle == 0
:Copilot enable
let g:toggle = 1
echo "Copilot Enabled"
else
:Copilot disable
let g:toggle = 0
echo "Copilot Disabled"
endif
endfunction
noremap <F12> :call CopilotToggle(g:toggle)<CR>
```

25) count words and number of lines in vim

```jsx
press g and then Ctrl+g
```

26) Auto complete in vim using shortcuts

```jsx
* `<C-x><C-l>` - whole lines                                     
* `<C-x><C-n>` - keywords in the current file                    
* `<C-x><C-k>` - keywords in 'dictionary'                        
* `<C-x><C-t>` - keywords in 'thesaurus', thesaurus-style        
* `<C-x><C-i>` - keywords in the current and included files      
* `<C-x><C-]>` - tags                                            
* `<C-x><C-f>` - file names                                      
* `<C-x><C-d>` - definitions or macros                           
* `<C-x><C-v>` - Vim command-line                                
* `<C-x><C-u>` - user defined completion                         
* `<C-x><C-o>` - omni completion                                 
* `<C-x>s` &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - spelling suggestions
```

27) Searching backwards with ? In vim to search term contain / characters without needing to escape them

28) Replace lines with certain patterns

```jsx
The command you posted will replace all instances of `cout` with `=`, which isn't what OP was interested in. Here's a breakdown of the command I posted:

```
g/cout/         # matches each line containing `cout`
       s/=/is   # for each of those matched lines, replace `=` with `is`
```
```

29) How to search case insensitive in vim

```jsx
/requestUpdate\c (where \c-> is case insensitivie search)
```

30) How to go to last yanked text (it worked before insert mode)

```jsx
'] or '[
```

31) Rename a current file in vim

```jsx
:edit %:p:h
```

32) Get a better view of the surrounding code in Vim:

```jsx
ctrl-e - Move viewport up one line
ctrl-y - Move viewport down one line
```

33) Create pre defined templates for certain filetype like (C++)

```jsx
	1) create a template directory in nvim
~/AppData/Local/nvim/plugged/templates (if templates directory is not there then create it)
	2) create a file called skeleton.cpp (inside templates directory)
	3) add the template code inside the file
		#include<bits/stdc++.h>
		using namespace std;
		
		int main(){
		
		}
   4) Add the following line in the .vimrc or .init.vim
   :autocmd BufNewFile *.cpp 0r ~/AppData/Local/nvim/plugged/templates/skeleton.cpp)
```

34) Increment or decrement a number in vim

```jsx
1) visual select the list
then press g+ cntrl+A   (it will increment the number)
then press g+ cntrl+x   (it will decrement the number)
:set nrformats+=alpha
set binary number
0b00000000 (where 0b representes binary number)
0xXX (its a hexadecimal value)
```

35) Print all substitution before replacing them

```jsx
:g/MATCH/#|s/MATCH/REPLACE/g|
```

36) How to do text expand in vim

```jsx
in your inti.vim or .vimrc file 
source $HOME/.config/nvim/general/abb.vim (where abb is abbrevation)

Abbrevation example is
ab teh the (it replace teh with the)
```

37) How to paste current filename in Vim

```jsx
in command mode type
:put=expand('%:t')
echo expand('%:r')
See :help expand:

	Modifiers:
		:p		expand to full path
		:h		head (last path component removed)
		:t		tail (last path component only)
		:r		root (one extension removed)
		:e		extension only
```

38) set cursor column in git

```jsx
:set cuc
:set nocuc
```

39) 

Press **ga** in Vim to see details about the character under the cursor.

The hex code is useful if you need to insert it into a replacement regex.

```jsx
:s/[``]/"/g
where hex code is 201d
```

40) Lost inside your parenthesis? Tangled up in a web of Lisp?

Vim can highlight the other side of your current bracket with :set showmatch

41) Repeat jumps in vim

```jsx
:+10
then run @: to repeat last command 
```

42) Appends to the substitution

```jsx
:s/apple/\0s
(it convert apple into apples)
```

43) create a new buffer in vim

```jsx
:enew
```

44) Adding empty lines between lines

```jsx
:%s/$/\r/g
$ is for end of line 
\r is adding new line 
g do it globally not just first occurrence

```

45) Go to previous line in vim

```jsx
''
```

46) current files in folder using expression register

```jsx
=system('ls')
```

47) Stop vim from yanking visual selected text (Put this in inti.vim or .vimrc)

```jsx
xnoremap p pgvy

When you paste in visual mode (x):

    It select what has been previously selected (gv) and
    Yank it (y)
```

48) Delete empty lines in Vim

```jsx
:g/^$/d
```

49) Vim’s zero-width ‘pattern start’ search atom

```jsx
/\zs
e.g namespace App\Http\Controllers\Api; (match API after controlers)
/controllers\\\zsApi
```

50) vim tablularize plugin

```jsx
Plug 'godlygeek/tabular'
:<,>Tabularize /=
```

51) Search for all uppercase letters in vim

```jsx
/\v<\u+>
```

52) Delete all white spaces until first character

```jsx
%s/^\s*//g
```

53) Split a long string into multiple lines by delimiter

```jsx
:%s/,/\r/g
```

54) Replace all occurrence of text with yank text

```jsx
:%d|put+
```

55 ) check lsp implementation supports code actions or not command

```jsx
:lua print(vim.inspect(vim.lsp.buf_get_clients()[1].resolved_capabilities))
```

56) Print a lua table in vim

```jsx
:lua print(vim.inspect(vim.lsp.util.make_position_params()))
where (vim.inspect prints the lua table)
```

57) How to encrypt a file using vim

```jsx
:X password
where password is encryption key
if you want to remove it then don't put any password 
```

58) Delete lines that does not match a patter

n

```jsx
v/@/d
where it will not delete lines that starts with @
```

59) Use !! key to use terminal commands in vim

60) Delete from current line to end of file (document)

```jsx
dG (in normal mode)
```

61) Here's how you can comment and uncomment code using a visual selection and the norm command:

```jsx
:norm i# (comment)
:norm x ( for uncomment)
```

62) vim gn  command repeat the last search and replace with .

- `/ million` – Finds the first match of ” million”
- `cgn` – Changes the next match of my pattern
- `M USD<Esc>` – My replacement pattern
- Then I just press `.` to repeat it

63) Vim Skelton to pre populate text in files

```jsx
autocmd BufNewFile readme.md 0r ~/skeletons/readme.md
autocmd BufNewFile *.sh 0r ~/skeletons/bash.sh
```

In this case, I’ve created a new directory inside my home directory called `skeletons` but you could put these anywhere. Here’s how this works:

- `autocmd` – run this automatically on some event
- `BufNewFile` – this is Vim’s new file event
- `readme.md` – this is the pattern you want the new file to match
- `0r` – read into the buffer starting at line 0, the first line
- `~/skeletons/readme.md` – the file to read in

64) Repeat the last substitution in vim

```jsx
• :& - repeat but reset flags
• :&& - repeat and keep flags
• :%& - repeat on file, reset flags
• :%&& - repeat on file, keep flags
```

65) chain commands in vim

```jsx
:w|so %
```

66) jump between methods or functions in Vim

```bash
]m jump to beginning of next method
]M end of next
[m beginning of previous
[M end of previous
```

67) change whole buffer using normal command

```jsx
:%norm csw"A: "",
it uses vim surround plugin to add quotes i.e change surround word using quotes
```

68) Run vim with preserve environment

```jsx
sudo -e vim filname
```

69) Going end to the virtual line in vim

```jsx
g$
```

70) search in buffers commands

```jsx
:Blines (current buffer)
:Lines (opened buffer)
```

71) Use & in your replacement patterns to insert the matched text. For example, adding markdown links to URLs:

```jsx
%s/https.*/[[&](Vim%20Commands%204a608cdcc7f3497cb3cf07c003bd32b7.md)]()/g
```

72) Extract lines from a file by visually selecting them and then using

```jsx
:w path/to/file
```

73) Get current filename in vim

```jsx
:echo expand('%')
```

74) Load manually plugins by vim plug

```jsx
Plug '~/AppData/Local/nvim/plugged/cpp'
Plug '~/AppData/Local/nvim/plugged/coolvim/'   (after this do :PlugInstall)
```

75) vim plug create with own repo

```jsx
create plugin directory (inside ~/AppData/Local/nvim/plugged)
inside plugin directory copy the file.vim
also create autoload directory and put the same file.
```

76) open Last edited file in vim

```jsx
cntrl+o cntrl+o
```

77) increment number inside large text

```jsx
g cntrl+A
```

78) Global substitute command in vim pattern

```jsx
g/text_to_search/command
e.g. g/onclick/norm f{ia"
```

79) Get old commits of file using vim-fugitive

```jsx
:0Gclog   (log should be small l)
```

80) select a function using keybindings

```jsx
nnoremap <leader>vf va{V
```

81) Vim's **gn** command will go to the next match and select it. It is used as repeatable to replace text.

82) vertical split in vim with extra functionality

```jsx
:vsp %:h (will expand current working directory)
:vsp filename.txt
Cntrl+| (will zoom the vertical split full height)
Cntrl+= (will resize equal size to all split window) 
```

83) Permanently delete all marks and write to file in neovim

```jsx
delmarks A-Za-0-9
:wshada! (this is only neovim command)
```

84) find fuzzy search using FZF

```jsx
:BLines (current buffer)
:Lines (for all buffer opens)
: History: ( search for all history)
```

85) Remove lines containing a word in vim

```jsx
:g /word/d 
:g!/word/d (not delete lines that contain word)
```

86) Genereate ctags for php in vim for easy navigation

```bash
sudo apt install ctags -y
ctags -R --languages=php . (where . is current working directory. cntrl+] goes to definition)
```

87) To quickly repeat the last word search /foo

```jsx
type/ and then enter it will repeat
last word foo
```

88) Extract lines from a file by visually selecting them and then using :w path/to/file

89) Encrypt a file in vim using :X

```jsx
save file with
:X 
to remove encryption type without password
Note: This is only supported in vim but not in neovim
```

90) close all buffers except the current one

```php
:%bd|e#
or bd|e#
```

91) Instead of confirming every substitutions, print them all out for a quick review at a glance

```bash
:g/MATCH/#|s/MATCH/REPLACE/g|#
```

92) set leader key command in linux

```jsx
set timeoutlen=500
```

93) Vim paste clipboard using terminal mode

```bash
:0put +
```

94) difference of files in vim without saving to a file (means with new buffer)

```bash
windo diffthis
windo diffoff
```

95) How to check runtime 

```jsx
:h rtp (where rtp is runtime path)
```