# powershell profile

```jsx
$profile (it will show the path of profile)
for e.g C:\Users\bhaveshverma\Documents\WindowsPowerShell
```

and the profile.ps1 file is 

```jsx
Invoke-Expression (& { (lua "C:\Program Files (x86)\clink\1.2.35.fa2a3e\z.lua" --init powershell) -join "`n" })
function fzf_directory(){ cd (fd -t d -X printf "%s/\n" '{}' | sed "s/]/``]/g" | sed "s/\[/``[/g"  | fzf) }
New-Alias zz fzf_directory
function one_directory_back{cd ..}
New-Alias .. one_directory_back
function two_directory_back{cd ../..}
New-Alias ... two_directory_back
```

```jsx
create a powershell profile by the following command
New-Item -Type File -Force $PROFILE
```