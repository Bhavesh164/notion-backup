# 17) Run remote desktop on WSL2

```jsx
!Ubuntu GUI commands:
sudo apt update && sudo apt -y upgrade
sudo apt-get purge xrdp
sudo apt install -y xrdp
sudo apt install -y xfce4
sudo apt install -y xfce4-goodies

sudo cp /etc/xrdp/xrdp.ini /etc/xrdp/xrdp.ini.bk
sudo sed -i 's/3389/3390/g' /etc/xrdp/xrdp.ini
sudo sed -i 's/max_bpp=32/#max_bpp=32\nmax_bpp=128/g' /etc/xrdp/xrdp.ini
sudo sed -i 's/xserverbpp=24/#xserverbpp=24\nxserverbpp=128/g' /etc/xrdp/xrdp.ini
echo xfce4-session > ~/.xsession

sudo vim /etc/xrdp/startwm.sh
!comment these lines to:
unset DBUS_SESSION_BUS_ADDRESS
unset XDG_RUNTIME_DIR
.$HOME/.rofile
# test -x /etc/X11/Xsession && exec /etc/X11/Xsession
# exec /bin/sh /etc/X11/Xsession

# xfce
startxfce4

sudo /etc/init.d/xrdp start

!Now in Windows, use Remote Desktop Connection
localhost:3390

!Then login using your Ubuntu username and password

for troubleshooting

sudo systemctl stop xrdp 
sudo systemctl start xrdp
sudo ls -lat /run/xrdp/xrdp.pid
sudo more /run/xrdp/xrdp.pid
ps -ef | grep xrdp
```

Run the following command to startup automatically xrdp

```jsx
sudo systemctl enable --now xrdp
```