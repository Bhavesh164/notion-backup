# codeigniter tricks

1) How to run two core controllers in CodeIgniter

```sql
function my_autoloader($class) {
    if (strpos($class, 'MY_') !== 0) { 
        if (file_exists($file = APPPATH . 'core/' . $class . '.php')) { 
            include $file;
        }
      }
    }
spl_autoload_register('my_autoloader');
```

**Note:** Add this snippet in the end of config.php file