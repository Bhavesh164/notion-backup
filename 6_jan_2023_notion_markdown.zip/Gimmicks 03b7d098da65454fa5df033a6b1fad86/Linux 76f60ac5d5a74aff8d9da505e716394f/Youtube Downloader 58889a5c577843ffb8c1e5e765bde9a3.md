# Youtube Downloader

1) make youtube dowload with aria2c

```jsx
alias youtube='yt-dlp -S "res:480" -f "(mp4)" --external-downloader aria2c --external-downloader-args "-j 16 -x 16 -s 16 -k 1M"'
```