# Jupyter Notebooks

Steps to install

1) Download miniconda from the website (it is a shell script)

```jsx
bash Miniconda3-py38_4.12.0-Linux-x86_64.sh (to install)
```

2) Run the following commands to install C++ jupiter kernel

```jsx
1) conda create -n cling
2) source activate cling
3) conda deactivate (to deactivate cling)
4) conda config --set auto_activate_base false (deactive base at start)
```

3) Install C++ juypter dependencies

```jsx
conda install xeus-cling juypterlab -c conda-forge
Note:- It will take time
```

4) Execute jupyter-lab from the terminal to launch

```jsx
juypter-lab
```

5) side note

```jsx
The packages are available in anaconda.org where package name is juypterlab
and channel name is conda-forge
```