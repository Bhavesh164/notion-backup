# fzf_directories.sh

```bash
#!/usr/bin/env bash
if [[ -z "$1" ]]; then
		dir="$(find $HOME -name '.*' -prune -o -print | fzf)";
		if [[ -f "$dir" ]]; then
			cd "$(dirname "$dir")"
		elif [[ -d "$dir" ]]; then
			cd "$dir"
		fi
	exec bash
	exit 1;
fi
while getopts h flag; do
	case $flag in
		h)
		dir="$(find $HOME | fzf)";
		if [[ -f "$dir" ]]; then
			cd "$(dirname "$dir")"
		elif [[ -d "$dir" ]]; then
			cd "$dir"
		fi
		exec bash
		exit 1;
		;;
	esac
done
```