# Naming your script with symbolic links

```bash
#!/bin/bash
[[ $1 ]] && url="$*" || url="$(xclip -o)" 
 
#"aac", "flac", "mp3", "m4a", "opus", "vorbis", or "wav"
 
format="$(basename $0|sed 's/yt//g')"
 
echo "$url"
youtube-dl --extract-audio --audio-format $format "$url"||
youtube-dl --extract-audio "$url"
```

in this we need to use symbolic links

like ln -s ytmusic ytmp3

ln -s ytmusi ytwav