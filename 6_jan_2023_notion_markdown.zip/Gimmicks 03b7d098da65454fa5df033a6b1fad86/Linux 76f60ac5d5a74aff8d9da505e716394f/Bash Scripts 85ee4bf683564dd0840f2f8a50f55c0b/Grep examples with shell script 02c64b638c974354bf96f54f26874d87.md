# Grep examples with shell script

Here are a few examples of how the **`-q`** flag can be used in Bash scripts:

1. Check if a package is installed on the system:

```bash
#!/bin/bash

# Check if the "nginx" package is installed
if dpkg -s nginx | grep -q "Status: install ok installed"; then
  echo "Nginx is installed"
else
  echo "Nginx is not installed"
fi
```

In this example, the **`dpkg -s`** command is used to query the status of the **`nginx`** package. The output of this command is piped to **`grep`**, which searches for the string "Status: install ok installed". If this string is found, **`grep`** exits with a success exit code, indicating that the **`nginx`** package is installed. If the string is not found, **`grep`** exits with a failure exit code, indicating that the package is not installed.

1. Check if a process is running:

```bash
#!/bin/bash

# Check if the "mysqld" process is running
if ps aux | grep -q "[m]ysqld"; then
  echo "MySQL is running"
else
  echo "MySQL is not running"
fi
```

In this example, the **`ps aux`** command is used to list all running processes. The output of this command is piped to **`grep`**, which searches for the string "[m]ysqld". The square brackets around **`m`** are used to prevent **`grep`** from matching itself in the output (since the **`ps`** command lists **`grep`** as one of the running processes). If the **`mysqld`** process is found, **`grep`** exits with a success exit code, indicating that the process is running. If the process is not found, **`grep`** exits with a failure exit code, indicating that it is not running.

1. Check if a file exists:

```bash
#!/bin/bash

# Check if the file "input.txt" exists
if ls | grep -q "input.txt"; then
  echo "Input file exists"
else
  echo "Input file does not exist"
fi
```

In this example, the **`ls`** command is used to list the files in the current directory. The output of this command is piped to **`grep`**, which searches for the string "input.txt". If the file is found, **`grep`** exits with a success exit code, indicating that the file exists. If the file is not found, **`grep`** exits with a failure exit code, indicating that it does not exist.