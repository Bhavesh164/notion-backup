# Functions with menu

```bash
function ip(){
  ifconfig wlp3s0|grep inet|grep -v inet6|awk '{print $2}'
}
 
function ssid(){
  iwgetid -r
}
 
function date_format(){
  date +%Y-%m-%d
}
 
function running_time(){
  uptime|cut -d\, -f1
}
 
function hello(){
  echo "Hello World"
}
 
function bye(){
  echo "Good-Bye"
}
 
[[ "$1" ]] && $1 || eval $(grep '^function' $0|awk '{print $2}'|cut -d\( -f1|fzf --prompt "Selection a Function: " )
```