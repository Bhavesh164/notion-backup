# Install pipewire on ubuntu 20.04

### How to install PipeWire on Ubuntu Linux December 10, 2021 10:52 AM by [Korbin Brown](https://linuxconfig.org/author/korbinpublisher)

The purpose of this tutorial is to install PipeWire on Ubuntu Linux. 
PipeWire is a sound server that can handle playback and capturing of 
audio and video streams. It is a worthy replacement to other multimedia 
frameworks such as PulseAudio, which is the default on Ubuntu, and 
others.
PipeWire was developed by Wim Taymans at Red Hat, and aims to provide better handling of audio and video for [Linux systems](https://linuxconfig.org/linux-download).
 It does so by providing lower lantency than other sound servers and 
also has a superior processing engine. The official site is [pipewire.org](https://pipewire.org/).
 Another use case for installing PipeWire is if you are having audio 
compatibility problems on Ubuntu, such as your Bluetooth device not 
working.

In this tutorial, we will cover the step by step instructions to install PipeWire on [Ubuntu Linux](https://linuxconfig.org/ubuntu-linux-download).
 You will also see how to use PipeWire as your main sound server on 
Ubuntu, which replaces PulseAudio. We will also show how to revert the 
changes, in case you decide that PipeWire is not for you and you want to
 restore to system defaults.

**In this tutorial you will learn:**

- How to enable PipeWire PPA repository
- How to install PipeWire software and additional libraries
- How to disable PulseAudio from running by default
- How to enable PipeWire as the default sound server in Ubuntu
- How to verify current sound server in Ubuntu
- How to revert PipeWire installation and restore PulseAudio

![https://linuxconfig.org/wp-content/uploads/2021/12/00-how-to-install-pipewire-on-ubuntu-linux.png](https://linuxconfig.org/wp-content/uploads/2021/12/00-how-to-install-pipewire-on-ubuntu-linux.png)

How to install PipeWire on Ubuntu Linux

| Category | Requirements, Conventions or Software Version Used |
| --- | --- |
| System | https://linuxconfig.org/ubuntu-linux-download |
| Software | PipeWire |
| Other | Privileged access to your Linux system as root or via the sudo command. |
| Conventions | # – requires given https://linuxconfig.org/linux-commands to be executed with root privileges either directly as a root user or by use of sudo command$ – requires given https://linuxconfig.org/linux-commands to be executed as a regular non-privileged user |

## How to Install PipeWire on Ubuntu Linux

---

---

Follow the step by step instructions below to install PipeWire on your 
Ubuntu system. This also includes replacing the default sound server 
(PulseAudio) with PipeWire.

Although PipeWire can be installed from Ubuntu’s default 
repositories, it is recommended that you use the PPA repo in order to 
obtain a more up to date version. It will also give you access to some 
additional packages that we recommend installing alongside PipeWire, to 
ensure maximum compatibility with your audio devices.

1. Start by opening a [command line](https://linuxconfig.org/linux-command-line-tutorial) terminal and typing the following command to add the PipeWire PPA.
    
    ```
    $ sudo add-apt-repository ppa:pipewire-debian/pipewire-upstream
    
    ```
    
2. Next, execute the following two commands to install the PipeWire package on Ubuntu with `apt` [package manager](https://linuxconfig.org/comparison-of-major-linux-package-management-systems). You should also install the `pipewire-audio-client-libraries` package at the same time.
    
    ```
    $ sudo apt update
    $ sudo apt install pipewire pipewire-audio-client-libraries
    
    ```
    
3. If you are planning to use Bluetooth, GStreamer, or JACK devices
with your Ubuntu system, it is also recommended that you install some
additional libraries. Otherwise, you may encounter an error when trying
to use one of your devices, such as `Bluetooth headset won’t connect after installing pipewire` when trying to use a Bluetooth headset.
    
    ```
    $ sudo apt install gstreamer1.0-pipewire libpipewire-0.3-{0,dev,modules} libspa-0.2-{bluetooth,dev,jack,modules} pipewire{,-{audio-client-libraries,pulse,media-session,bin,locales,tests}}
    
    ```
    
4. After installation has completed, run the following command to reload the daemon in systemd.
    
    ```
    $ systemctl --user daemon-reload
    
    ```
    
5. Next, run the following command to disable PulseAudio in Ubuntu. It
will no longer be needed, since we are using PipeWire. However, we will
keep it installed on the system in case we need to revert these changes
later. These commands will disable the service from running and starting up automatically.
    
    ---
    
    ---
    
    ```
    $ systemctl --user --now disable pulseaudio.service pulseaudio.socket
    
    ```
    
6. Now that PulseAudio is disabled, we can start PipeWire and enable it to run automatically upon system boot.
    
    ```
    $ systemctl --user --now enable pipewire pipewire-pulse
    
    ```
    
7. As a final step, run the following command to ensure that PipeWire is running.
    
    ```
    $ pactl info
    
    ```
    
    Command shows that PipeWire is running on Ubuntu
    
    ![https://linuxconfig.org/wp-content/uploads/2021/12/01-how-to-install-pipewire-on-ubuntu-linux.png](https://linuxconfig.org/wp-content/uploads/2021/12/01-how-to-install-pipewire-on-ubuntu-linux.png)
    

That’s all there is to it. You are now using PipeWire as your default sound server on Ubuntu.

## Revert PipeWire Changes

If you decide that you need to revert the changes you have made by 
installing PipeWire and disabling PulseAudio, follow the steps below to 
undo the changes.

1. Start by opening a terminal and uninstalling the PipeWire packages that we installed earlier.
    
    ```
    $ sudo apt remove pipewire pipewire-audio-client-libraries
    
    ```
    
2. Also remove the additional PipeWire libraries for Bluetooth, GStreamer, and JACK if you installed them before.
    
    ---
    
    ---
    
    ```
    $ sudo apt remove gstreamer1.0-pipewire libpipewire-0.3-{0,dev,modules} libspa-0.2-{bluetooth,dev,jack,modules} pipewire{,-{audio-client-libraries,pulse,media-session,bin,locales,tests}}
    
    ```
    
3. After the removal has completed, run the following command to reload the daemon in systemd.
    
    ```
    $ systemctl --user daemon-reload
    
    ```
    
4. Use the following systemd command to re-enable the PulseAudio
service. This command will start the service right now and also enable
it to start automatically upon system reboots.
    
    ```
    $ systemctl --user --now enable pulseaudio.service pulseaudio.socket
    
    ```
    
5. As a final step, run the following command to ensure that PulseAudio has been completely restored.
    
    ```
    $ pactl info
    
    ```
    

## Closing Thoughts

In this tutorial, we saw how to install PipeWire on Ubuntu Linux and 
use it as the default sound server. This also included installing 
additional PipeWire audio and video libraries to maximize compatibility 
with peripheral devices, and disabling the default PulseAudio services 
from running with systemd. If you find that PipeWire is causing problems
 with your audio or video, you can always follow the steps to revert the
 changes and restore PulseAudio.

---

### If first one is not working. See second one

I was facing the same issue with Oneplus Wireless Z Bass edition. My headset microphone was not detected by PulseAudio and the problem is that my headphones don't have HSP profile, only HFP profile. After trying for 2 days, I came to the solution of replacing PulseAudio with Pipewire sound server, which supports HSP, HFP and A2DP by itself. So there will be no need to install any other utility like `ofono`, `phonesim`. Also, to be noted that my problem wasn't resolved even after following all the steps to configure `ofono` in PulseAudio. So I came up with the steps to replace PulseAudio with PipeWire.

Here is the detailed article I have written to resolve this problem, the steps of which I'm also adding here. You can follow it and most probably be able to solve your problem.

[Bluetooth headset microphone not detected](https://atish3604.medium.com/solved-bluetooth-headset-mic-not-working-detected-in-ubuntu-20-04-86a5236444d0)

Open your terminal and follow these steps:

1. We will use a PPA for adding Pipewire to Ubuntu 20.04, which is maintained regularly:
    
    ```
    sudo add-apt-repository ppa:pipewire-debian/pipewire-upstream
    
    ```
    
2. To update the PPA packages in your system do:
    
    ```
    sudo apt update
    
    ```
    
3. Install the package:
    
    ```
    sudo apt install pipewire
    
    ```
    
4. There is also a dependency needed to be installed with Pipewire, otherwise you will face the issue of *“Bluetooth headset won’t connect after installing pipewire”*. Install the dependency by:
    
    ```
    sudo apt install libspa-0.2-bluetooth
    
    ```
    
5. Now, to install the client libraries:
    
    ```
    sudo apt install pipewire-audio-client-libraries
    
    ```
    
6. Reload the daemon:
    
    ```
    systemctl --user daemon-reload
    
    ```
    
7. Disable PulseAudio:
    
    ```
    systemctl --user --now disable pulseaudio.service pulseaudio.socket
    
    ```
    
8. If you are on Ubuntu 20.04, you also need to “mask” the PulseAudio by:
    
    ```
    systemctl --user mask pulseaudio
    
    ```
    

I am not sure but, if possible, you can try to run this on other versions too.9. After a new update of Pipewire, you also need to enable `pipewire-media-session-service`:

```
   systemctl --user --now enable pipewire-media-session.service

```

1. You can ensure that Pipewire is now running through:
    
    ```
    pactl info
    
    ```
    
    This command will give the following output, in Server Name you can see:
    
    ```
    PulseAudio (on PipeWire 0.3.28)
    
    ```
    
    Things should be working by now and you can see your microphone.
    

If it doesn’t show up, then try restarting Pipewire by this command:

```
systemctl --user restart pipewire

```

> Edit: You need to uninstall ofono and phonesim from your system if you have them installed.
> 

```
sudo apt remove ofono
sudo apt remove ofono-phonesim

```

If it’s still not showing your microphone, you can try rebooting once and remove and pair your Bluetooth device again to check if it works now.

I hope I have helped you solve your problem.

If you want to rollback all the changes we did, you can do it by using:

```
systemctl --user unmask pulseaudio
systemctl --user --now disable pipewire{,-pulse}.{socket,service}
systemctl --user --now enable pulseaudio.service pulseaudio.socket
```