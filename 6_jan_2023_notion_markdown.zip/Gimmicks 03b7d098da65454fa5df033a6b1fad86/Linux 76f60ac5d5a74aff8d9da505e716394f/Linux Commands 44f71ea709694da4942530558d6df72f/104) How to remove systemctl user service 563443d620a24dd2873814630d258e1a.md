# 104) How to remove systemctl user service

To remove a user systemd service, you will need to follow these steps:

1. Stop the service using the following command:

```bash
Copy code
systemctl --user stop service_name

```

Replace "service_name" with the name of your service.

1. Disable the service to prevent it from starting automatically at boot time using the following command:

```bash
Copy code
systemctl --user disable service_name

```

1. Remove the service unit file from the **`~/.config/systemd/user/`** directory.
2. Reload the systemd daemon to pick up the change:

```bash
Copy code
systemctl --user daemon-reload

```

That's it! Your service should now be removed from systemd. You can use the **`systemctl --user list-unit-files`** command to verify that the service unit file has been removed.

I hope this helps! Let me know if you have any additional questions.