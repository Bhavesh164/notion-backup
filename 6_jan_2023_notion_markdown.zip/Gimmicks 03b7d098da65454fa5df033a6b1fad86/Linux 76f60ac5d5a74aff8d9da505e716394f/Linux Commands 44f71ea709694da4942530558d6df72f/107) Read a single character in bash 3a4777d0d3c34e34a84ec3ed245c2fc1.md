# 107) Read a single character in bash

To read a single character from the keyboard in Bash, you can use the **`read`** command with the **`-n`** option to specify the number of characters to read and the **`-s`** option to disable echo, like this:

```bash
Copy code
read -n 1 -s char
```

This will read one character from the keyboard and store it in the variable **`char`**, without echoing the character to the terminal.

Here's an example of how you could use this to read a single character and then take action based on the character that was entered:

```
Copy code
read -n 1 -s char
case "$char" in
  y|Y ) echo "Yes";;
  n|N ) echo "No";;
  * ) echo "Invalid input";;
esac
```

This script will read one character from the keyboard and then check if it is a 'y' or 'Y' (for yes) or an 'n' or 'N' (for no). If it is either of those, it will print "Yes" or "No" respectively. If it is any other character, it will print "Invalid input".