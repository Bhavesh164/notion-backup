# Add Missing API Keys

By far the simplest way to handle this now is with Y-PPA-Manager (which now integrates the `launchpad-getkeys` script with a graphical interface).

1. To install it, first add the webupd8 repository for this program:
    
    ```
    sudo add-apt-repository ppa:webupd8team/y-ppa-manager
    
    ```
    
2. Update your software list and install Y-PPA-Manager:
    
    ```
    sudo apt-get update
    sudo apt-get install y-ppa-manager
    
    ```
    
3. Run y-ppa-manager (i.e. type `y-ppa-manager` then press enter key).
4. When the main y-ppa-manager window appears, click on "Advanced."
5. From the list of advanced tasks, select "Try to import all missing GPG keys" and click OK.
    
    You're done! As the warning dialog says when you start the operation,
     it may take quite a while (about 2 minutes for me) depending on how 
    many PPA's you have and the speed of your connection.