# GNU GPG Tutorial

```jsx
Note: official gpg folder is in home direcotry called .gnupg
1) export GNUPGHOME=/tmp/gnupg
2) gpg --list-keys
3) sudo chmod 0700 /tmp/gnupg
After this command there will be no error
4)gpg --full-generate-key
Now you want to update the expiration date
5) gpg --edit-key bhavesh@gmail.com
it will give you gpg prompt
6) gpg > list
7) gpg> key 0
8) gpg> expire
9) gpg> save
It will go out of gpg prompt
Now if you want to change your passphrase (password)
10) gpg --passwd bhavesh@gmail.com
Now if you want to revoke the certificate
11) gpg --import revoke-bhaveshexample.asc
Now you want to show your gpg key
12) gpg --export --armor bhavesh@example.com
If  you want to save it to a file
13) gpg --export --armor --output bhavesh.gpg.pub bhavesh@exmaple.com
14) if you want to save your passpharse so that you don't need to enter it again and again
in ~/.gnugp folder create a file name gpg-agent.conf
and write the following commands
default-cache-ttl 604800
max-cache-ttl 604800
- Now how to encrypt a file using gpg
15) gpg -r bhavesh@example.com -e file.txt (where r is recipient)
The file is created called file.gpg
16)gpg -d file.gpg (it is used to decrypt the file) or
gpg -d file.gpg >> newfile.txt
```