# 106) Reduce video quality with ffmpeg

To reduce the video quality with ffmpeg, you can use the **`-crf`** flag followed by a value between 0 and 51, where a lower value represents higher quality and a higher value represents lower quality. For example, the following command will reduce the video quality to the lowest possible value:

```
Copy code
ffmpeg -i input.mp4 -crf 51 output.mp4

```

You can also use the **`-b:v`** flag to specify the bitrate for the video. For example, the following command will set the bitrate to 1000 kbps:

```
Copy code
ffmpeg -i input.mp4 -b:v 1000k output.mp4

```

Keep in mind that reducing the video quality may result in a loss of visual quality and may not be suitable for all use cases. You may want to experiment with different values to find the right balance between video quality and file size

-——————————————————————-

HELP about flags

The **`-crf`** flag stands for "constant rate factor" and is used to specify the quality of the video output when using the x264 codec in ffmpeg. It takes a value between 0 and 51, where a lower value represents higher quality and a higher value represents lower quality. The default value is 23, which is a good balance between quality and file size.

The **`-crf`** flag works by adjusting the quantization parameter of the video, which determines how much detail is preserved in the output video. A higher quantization parameter results in a lower quality video with a smaller file size, while a lower quantization parameter results in a higher quality video with a larger file size.