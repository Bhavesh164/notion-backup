# Configure

```bash
#!/bin/bash

# Check for required dependencies
if ! command -v gcc > /dev/null; then
    echo "Error: gcc is not installed"
    exit 1
fi

# Check for optional dependencies
if command -v clang > /dev/null; then
    use_clang=true
else
    use_clang=false
fi

# Set build options based on system architecture
arch=$(uname -m)
if [ "$arch" = "x86_64" ]; then
    build_flags="-m64"
else
    build_flags="-m32"
fi

# Generate a Makefile based on the options and dependencies
cat > Makefile <<EOF
CC = gcc
CFLAGS = $build_flags

all:
    \$(CC) \$(CFLAGS) main.c -o myprogram

install:
    cp myprogram /usr/local/bin
EOF

echo "Configuration complete!"
```