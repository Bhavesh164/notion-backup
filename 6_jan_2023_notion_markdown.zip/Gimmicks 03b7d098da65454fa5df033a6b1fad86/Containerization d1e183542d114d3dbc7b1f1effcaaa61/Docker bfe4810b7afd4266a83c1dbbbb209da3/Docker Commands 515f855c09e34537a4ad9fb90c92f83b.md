# Docker Commands

1) List out containers in docker

```jsx
docker ps (it shows running containers)
docker ps -a (it shows all containers including stop conatiners)
```

2) To Start,stop and remove all containers in docker

```jsx
docker start $(docker ps -a -q)
docker stop $(docker ps -a -q)
docker remove $(docker ps -a -q)
```