# Increase QEMU KVM virtual disk size

1) sudo virsh shutdown rhel8

2) sudo virsh list (it should show empty)

3) sudo virsh domblklist rhel8

4) sudo qemu-img info /var/lib/libvirt/images/rhel8.qcow2

5) ssudo qemu-img resize /var/lib/libvirt/images/rhel8.qcow2 +10G      (increase disk size)

6) sudo virsh snapshot-list rhel8

Note: Please note that *qemu-img*
 can’t resize an image which has snapshots. You will need to first remove all VM snapshots.

7) sudo virsh snapshot-list rhel8

8) sudo virsh snapshot-delete --domain rhel8 --snapshotname snapshot1

9) sudo virsh snapshot-list rhel8 (it should show empty)

10) sudo qemu-img resize /var/lib/libvirt/images/rhel8.qcow2 +10G (it should show image resized)

11) sudo qemu-img info /var/lib/libvirt/images/rhel8.qcow2

12) sudo fdisk -l /var/lib/libvirt/images/rhel8.qcow2