# Mysql or Postgres Queries

### 1) How to find all the tables in MySQL with specific column names in them?

```sql
SELECT DISTINCT TABLE_NAME 
FROM INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME IN ('columnA','ColumnB')
AND TABLE_SCHEMA='YourDatabase';
```

### 2) How to find duplicate records in MySQL

```jsx
select id from tablename group by id having count(id)>=2;
```

### 3) How to import data in MySQL using command line in windows

```jsx
1) connect to mysql using following command
cmd: mysql -u root -p
2) use database
3) source file.sql (You can choose path)

```

4) How to loop over MYSQL Queries

```jsx
drop procedure if exists doWhile;
DELIMITER //  
CREATE PROCEDURE doWhile()   
BEGIN
DECLARE i INT DEFAULT 1; 
WHILE (i <= 75) DO
    INSERT INTO `role_permission` (permission_id, role_id) values (i, 1);
    SET i = i+1;
END WHILE;
END;
//  

CALL doWhile();
```

5) How to get the max value from a column with alphanumeric strings?

```jsx
SELECT MAX(CAST(SUBSTR(TRIM(rider_code),2) AS UNSIGNED)) FROM rider;
```

6) Import .Sql in Postgres using command line (Linux)

```jsx
psql -h localhost -d homestead_new -U postgres -f /home/bhavesh/Downloads/dump\ \(1\).sql
```

7) show database size in Postgre sql command line (linux)

```jsx
SELECT pg_size_pretty(pg_database_size('Database Name'));
```

8) How to import sql file in postgres

```jsx
psql -h localhost  -d homestead -U postgres -f ~/Downloads/dump.sql

Note: after this it asked password: root
```

9) List all sequence in database postgres

```jsx
SELECT * FROM information_schema.sequences;
```

10) drop sequence that does not associate with any table.

```jsx
drop sequence sequence_name;
```

11) list column name in database in postgres

```jsx
select t.table_schema,
       t.table_name
from information_schema.tables t
inner join information_schema.columns c on c.table_name = t.table_name 
                                and c.table_schema = t.table_schema
where c.column_name = 'status_type_id'
      and t.table_schema not in ('information_schema', 'aed365_prod')
      and t.table_type = 'BASE TABLE'
order by t.table_schema;
```

12) procedure to duplicate a table in postgresSQL

```jsx
CREATE TABLE tbl1 (LIKE tbl INCLUDING ALL);
-- only if there are serial columns:
CREATE SEQUENCE tbl1_tbl_id_seq;     -- one line per serial type ...
CREATE SEQUENCE "tbl1_Odd_COL_seq";  -- .. two in this example
ALTER SEQUENCE tbl1_tbl_id_seq OWNED BY tbl1.tbl_id;
ALTER SEQUENCE "tbl1_Odd_COL_seq" OWNED BY tbl1."Odd_COL";
ALTER TABLE tbl1
  ALTER tbl_id SET DEFAULT nextval('tbl1_tbl_id_seq'::regclass)
, ALTER "Odd_COL" SET DEFAULT nextval('"tbl1_Odd_COL_seq"'::regclass);
```

13) upgrade to postgres sql

```bash
https://stackoverflow.com/questions/60409585/how-to-upgrade-postgresql-database-from-10-to-12-without-losing-data-for-openpro
```

14) Retrieve comments in postgres sql

```jsx
select cols.column_name, 
 (select pg_catalog.obj_description(oid) from pg_catalog.pg_class c where c.relname=cols.table_name) as table_comment 
 ,(select pg_catalog.col_description(oid,cols.ordinal_position::int) from pg_catalog.pg_class c where c.relname=cols.table_name) as column_comment 
 from information_schema.columns cols 
 where cols.table_catalog='homestead' and cols.table_name='aeds'
```

15) convert epoch timestamp to date in postgres sql

```jsx
select to_timestamp(epoch_column)::date;
```

16) Group concat equivalent in postgres

```jsx
select string_agg(id::text,',') from tablename;
Note: dont include group by 
```

17) Best way to start xampp in ubuntu

```bash
sudo /opt/lampp/lampp start
or 
sudo /opt/lampp/uninstall (to uninstall xampp)
```