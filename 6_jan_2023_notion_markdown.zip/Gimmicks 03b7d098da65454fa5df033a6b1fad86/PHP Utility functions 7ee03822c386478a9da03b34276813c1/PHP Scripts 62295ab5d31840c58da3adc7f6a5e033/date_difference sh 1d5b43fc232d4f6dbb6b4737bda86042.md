# date_difference.sh

```php
#!/usr/bin/env php
<?php
echo "Enter first Date: ";
$first_date=fopen("php://stdin","r");
$first_date=fgets($first_date);
echo "Enter Second  Date: ";
$second_date=fopen("php://stdin","r");
$second_date=fgets($second_date);
$earlier = new DateTime($first_date);
$later = new DateTime($second_date);
echo $abs_diff = $later->diff($earlier)->format("%a")."\n";
?>
```

Input: Enter first Date: 20220713  (13 July 2022)

Input: Enter Second Date: 20220716  (16 July 2022)

Output: 3 (Days)