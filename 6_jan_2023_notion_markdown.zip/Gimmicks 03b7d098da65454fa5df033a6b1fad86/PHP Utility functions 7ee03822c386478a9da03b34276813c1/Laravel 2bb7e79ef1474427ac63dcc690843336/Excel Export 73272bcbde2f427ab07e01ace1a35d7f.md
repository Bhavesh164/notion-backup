# Excel Export

```php
<?php

namespace App\Services;

use Illuminate\Http\Request;
use App\Models\Municipality;
use App\Models\Category;
use App\Models\Report;
use Illuminate\Auth\EloquentUserProvider;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportService
{
    public function incident(Request $request)
    {
        // redirect output to client browser
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="incident_report' . now() . '.xlsx"');
        header('Cache-Control: max-age=0');

        $filter = $request->all() ?? [];
        $municipalities = (new Municipality)->getAll();
        $categories = (new Category)->getAll();
        $municipalities_dropdown = createDropDownFromCollection($municipalities);
        $category_dropdown = createDropDownFromCollection($categories);
        $data['municipality_overall_report'] = (new Report)->municipalityOverallReport($municipalities, $filter);
        $data['municipality_datewise_report'] = (new Report)->municipalityDatewiseReport($filter);
        $data['category_overall_report'] = (new Report)->categoryOverallReport($categories, $filter);
        $i1 = 4;
        $i2 = 4;
        $i3 = 4;
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Report Alto al Crimen');
        $sheet->setCellValue('A2', '');
        $sheet->setCellValue('A3', __('municipality'));
        $sheet->setCellValue('B3', __('quantity'));
        $sheet->setCellValue('D3', __('date'));
        $sheet->setCellValue('E3', __('quantity'));
        $sheet->setCellValue('G3', __('type'));
        $sheet->setCellValue('H3', __('quantity'));
        $sheet->getStyle('A1:A1')->getFont()->setBold(true);
        $sheet->getStyle('A3:H3')->getFont()->setBold(true);
        foreach ($data['municipality_overall_report'] as $key => $value) {
            $sheet->setCellValue("A$i1", $value['name']);
            $sheet->setCellValue("B$i1", $value['count']);
            $i1++;
        }

        foreach ($data['municipality_datewise_report']['count'] as $key => $value) {
            $sheet->setCellValue("D$i2", $value->incident_date);
            $sheet->setCellValue("E$i2", $value->count);
            $i2++;
        }

        foreach ($data['category_overall_report'] as $key => $value) {
            $sheet->setCellValue("G$i3", $value['name']);
            $sheet->setCellValue("H$i3", $value['count']);
            $i3++;
        }
        $writer = new Xlsx($spreadsheet);
        $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save('php://output');
    }
}
```