# How to enable virtual host in ubuntu

```jsx
Virtual host is disabled by default. IT can be enabled in the following file
1) sudo gedit /opt/lampp/etc/httpd.conf

479. # Virtual hosts
480. Include etc/extra/httpd-vhosts.conf    (uncomment only line 480)

2) go to /opt/lampp/etc/extra/httpd-vhosts.conf
add the following lines
<VirtualHost *:80>
    ServerName prosody.localhost.com
    DocumentRoot "/opt/lampp/htdocs/prosody"
</VirtualHost>

or you can also add /etc/apache2/sites-available it also works so no need step 1) in this case

3) go to /etc directory
find the **hosts files**
edit host file
127.0.0.1	prosody.localhost.com

```