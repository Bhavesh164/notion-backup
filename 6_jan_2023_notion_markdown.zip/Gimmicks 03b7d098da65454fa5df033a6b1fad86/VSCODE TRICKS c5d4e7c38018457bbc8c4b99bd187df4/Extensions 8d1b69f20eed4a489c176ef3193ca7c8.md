# Extensions

1) **All Autocomplete (By Atishay Jain)**

2) Auto Rename tag (By Jun Han)

3) copy directory path ( by daniels)

4) duplicate actions (by mrmlnc)

5) laravel goto (by Adrian)

6) laravel goto view (by codingyu)

7) MYSQL (by cweijan)

8) Nest comments (by Phil Sintara)

9) PHP Awesome snippets (by HakCorp)

10) PHP Intelephense (by Ben Mewburn)

11) **PHP Snippets from PHPStorm (by phiter fernandes)**

12) Project manager (by alessandro fragnani)

13) SFTP (by liximomo)

14) Vim (by vscodevim)

15) Visual Studio Intellicode (by microsoft)

16) VSCode open buffers (will-wow)