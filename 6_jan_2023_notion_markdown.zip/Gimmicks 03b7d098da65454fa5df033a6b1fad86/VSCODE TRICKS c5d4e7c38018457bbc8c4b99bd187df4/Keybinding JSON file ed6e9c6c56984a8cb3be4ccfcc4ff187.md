# Keybinding.JSON file

```jsx
// Place your key bindings in this file to override the defaults
[
    {
        "key":"tab",
        "command":"tab",
        "when":"editorTextFocus && !editorTabMovesFocus",
    },
    {
        "key":"shift+tab",
        "command":"outdent",
        "when":"editorTextFocus && !editorTabMovesFocus",                     
    },
    {
        "key": "alt+j",
        "command": "workbench.action.quickOpenSelectNext",
        "when": "inQuickOpen"
    },
    {
        "key": "alt+k",
        "command": "workbench.action.quickOpenSelectPrevious",
        "when": "inQuickOpen"
    },
		{
        "key": "tab",
        "command": "jumpToNextSnippetPlaceholder",
        "when": "editorTextFocus && inSnippetMode"
    },
		{
        "key": "tab",
        "command": "selectNextSuggestion",
        "when": "suggestWidgetMultipleSuggestions && suggestWidgetVisible && textInputFocus"
    },
		{
        "key": "shift+tab",
        "command": "selectPrevSuggestion",
        "when": "suggestWidgetMultipleSuggestions && suggestWidgetVisible && textInputFocus"
    },
		{
        "key": "shift+alt+j",
        "command": "editor.action.moveLinesDownAction",
        "when": "editorTextFocus && !editorReadOnly"
    },
    {
        "key": "shift+alt+k",
        "command": "editor.action.moveLinesUpAction",
        "when": "editorTextFocus && !editorReadOnly"
    },
 
]
```