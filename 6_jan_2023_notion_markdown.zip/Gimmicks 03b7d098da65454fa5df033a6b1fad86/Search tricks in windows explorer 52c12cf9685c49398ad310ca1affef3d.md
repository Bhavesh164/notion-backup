# Search tricks in windows explorer

# 1) Search files this week code

.php datemodified:this week

# 2) Search files by today

.php datemodified:today

# 3) Search files by date range

.php datemodified:11/18/18..11/20/18 (Month/date/year)

# 4) Exclude folder in search

.php datemodified:today -folder:(classes) -folder:(layouts)

# 5) Search file modified after a particular time

.php datemodified:‎‎2021-03-01 11:00:00 .. ‎‎2021-03-01 12:00:00 (datemodified:‎YYYY-MM-DD hh:mm:ss .. ‎YYYY-MM-DD hh:mm:ss)

or

.php modified:>2021-03-01 11:00:00 (datemodified:>YYYY-MM-DD hh:mm:ss)

# 6) Windows search tricks in CMD

```jsx
forfiles /D +04/01/2021 /S /M *.php /C "cmd /c echo @path"

/D -> for date
+04/01/2021  (monht/day/year)
/S -> recursively serach inside folders
/M -> match text pattern
/C -> for output "cmd /c echo @path"
```