# Gimmicks

[VSCODE TRICKS](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/VSCODE%20TRICKS%20c5d4e7c38018457bbc8c4b99bd187df4.md)

[Mysql or Postgres Queries](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Mysql%20or%20Postgres%20Queries%2041197264c3804b178b54f50bf83bcb71.md)

[Search tricks in windows explorer](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Search%20tricks%20in%20windows%20explorer%2052c12cf9685c49398ad310ca1affef3d.md)

[PHP Utility functions](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/PHP%20Utility%20functions%207ee03822c386478a9da03b34276813c1.md)

[codeigniter tricks](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/codeigniter%20tricks%206ffeb1d6e79e49ac86f523a4c14d751f.md)

[git](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/git%209764c156c1e14b97ac669f03e2d5cc57.md)

[jQuery](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/jQuery%20d1501e4a3a444568a54281b2f2878d8e.md)

[Vim](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Vim%2072482e7d694b40a5a69bc898777471bc.md)

[Linux commands](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Linux%20commands%20ca1bf250956b4c7b8156481ebc52636f.md)

[Windows](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Windows%20b5921f806f73416691cc21fdcee8948a.md)

[Google](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Google%201b9a5a2c86394adf89a6216db65dc10d.md)

[Linux](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Linux%2076f60ac5d5a74aff8d9da505e716394f.md)

[Browser](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Browser%201b67a572144846f08169b6156ca57de1.md)

[FrontEnd](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/FrontEnd%209ca7df50e38c425389ef5ab1f727af1b.md)

[Api](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Api%20db6722d1215d46499e944a0e5eefd6aa.md)

[Containerization](Gimmicks%2003b7d098da65454fa5df033a6b1fad86/Containerization%20d1e183542d114d3dbc7b1f1effcaaa61.md)