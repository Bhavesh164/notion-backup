# Learn Curl

```jsx
1) curl https://google.com -I (I flag for containting inforamtion about headers only)
2) curl https://google.com -Iv (v flag stand for verbose containting detailed information about headers only)
Note: curl output its contents to stderr (standard error not stdout (standard output))
3) curl https://google.com -Iv --stderr - | grep "expiry date" (also redirect to stdout using (-) flag)
alternative synatx for same command is
curl https://google.com -Iv 2>&1 | grep "expiry date"
```

2) Download website using wget

```jsx
wget -r -k --convert-links --adjust-extension https://intellisense.ca/
```