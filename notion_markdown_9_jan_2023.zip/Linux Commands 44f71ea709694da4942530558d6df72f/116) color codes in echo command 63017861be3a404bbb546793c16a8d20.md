# 116) color codes in echo command

```bash
The \033 is an ASCII escape code that can be used to set the text color in a terminal. 
The [31m that follows it specifies the color code for the text color.

Here is a list of some common color codes that you can use with 
the \033[31m escape sequence:

30: Black
31: Red
32: Green
33: Yellow
34: Blue
35: Magenta
36: Cyan
37: White
To use a color code, you can use the escape sequence \033[<color code>m. 
For example, to set the text color to red, you can use \033[31m. 
To reset the text color to the default value, you can use \033[0m.
```

Here's an example of how you can use the **`\033[31m`**
 escape sequence to print a message in red:

```bash
echo -e "\033[31mThis is a red message\033[0m"
```