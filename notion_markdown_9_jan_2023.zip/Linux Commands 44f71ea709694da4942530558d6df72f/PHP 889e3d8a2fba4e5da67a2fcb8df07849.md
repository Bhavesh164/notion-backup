# PHP

```bash
#!/usr/bin/env php
<?php
echo "Enter first Date: ";
$first_date=fopen("php://stdin","r");
$first_date=fgets($first_date);
echo "Enter Second  Date: ";
$second_date=fopen("php://stdin","r");
$second_date=fgets($second_date);
$earlier = new DateTime($first_date);
$later = new DateTime($second_date);
echo $abs_diff = $later->diff($earlier)->format("%a")."\n"; 
?>
```

2) second example with clipboard and shell execution

```bash
#!/usr/bin/env php
<?php
$handle=fopen("php://stdin","r");
$timestamp=fgets($handle);  //grab inside the input
$date=preg_replace('/\R/', '', trim(date('Y-m-d',(int)$timestamp)));
$pid=shell_exec("echo  " . escapeshellarg($date) . " | xclip -r -sel c | exit 0");
echo "Date is :$date\n";
?>
```