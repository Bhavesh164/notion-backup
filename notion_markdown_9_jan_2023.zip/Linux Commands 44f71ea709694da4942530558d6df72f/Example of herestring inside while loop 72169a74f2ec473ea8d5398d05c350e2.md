# Example of herestring inside while loop

```bash
# Set the variable 'words' to a list of words
words="apple banana cherry"

# Use the here string to pass the value of 'words' as standard input to the 'while' loop
while read -r word; do
  # Print each word to the console
  echo "$word"
done <<< "$words"
```

output will be

apple

banana

cherry